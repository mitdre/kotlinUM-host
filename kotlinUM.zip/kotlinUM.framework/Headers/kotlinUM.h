#import <Foundation/Foundation.h>

@class KUMCar, KUMPerson, KUMDog, KUMGarage;

@protocol KUMStdlibCollection, KUMStdlibIterable, KUMStdlibIterator;

NS_ASSUME_NONNULL_BEGIN

@interface KotlinBase : NSObject
-(instancetype) init __attribute__((unavailable));
+(instancetype) new __attribute__((unavailable));
+(void)initialize __attribute__((objc_requires_super));
@end;

__attribute__((objc_subclassing_restricted))
@interface KUMCar : KotlinBase
-(instancetype)initWithNumWheels:(int32_t)numWheels isSteeringWheelImpressive:(BOOL)isSteeringWheelImpressive numSeats:(int32_t)numSeats isConvertible:(BOOL)isConvertible owner:(KUMPerson*)owner NS_SWIFT_NAME(init(numWheels:isSteeringWheelImpressive:numSeats:isConvertible:owner:)) NS_DESIGNATED_INITIALIZER;

-(int32_t)component1 NS_SWIFT_NAME(component1());
-(BOOL)component2 NS_SWIFT_NAME(component2());
-(int32_t)component3 NS_SWIFT_NAME(component3());
-(BOOL)component4 NS_SWIFT_NAME(component4());
-(KUMPerson*)component5 NS_SWIFT_NAME(component5());
-(KUMCar*)doCopyNumWheels:(int32_t)numWheels isSteeringWheelImpressive:(BOOL)isSteeringWheelImpressive numSeats:(int32_t)numSeats isConvertible:(BOOL)isConvertible owner:(KUMPerson*)owner NS_SWIFT_NAME(doCopy(numWheels:isSteeringWheelImpressive:numSeats:isConvertible:owner:));
@property (readonly) int32_t numWheels;
@property (readonly) BOOL isSteeringWheelImpressive;
@property (readonly) int32_t numSeats;
@property (readonly) BOOL isConvertible;
@property (readonly) KUMPerson* owner;
@end;

__attribute__((objc_subclassing_restricted))
@interface KUMDog : KotlinBase
-(instancetype)initWithTailLength:(int32_t)tailLength isPanting:(BOOL)isPanting NS_SWIFT_NAME(init(tailLength:isPanting:)) NS_DESIGNATED_INITIALIZER;

-(int32_t)component1 NS_SWIFT_NAME(component1());
-(BOOL)component2 NS_SWIFT_NAME(component2());
-(KUMDog*)doCopyTailLength:(int32_t)tailLength isPanting:(BOOL)isPanting NS_SWIFT_NAME(doCopy(tailLength:isPanting:));
@property (readonly) int32_t tailLength;
@property (readonly) BOOL isPanting;
@end;

__attribute__((objc_subclassing_restricted))
@interface KUMGarage : KotlinBase
-(instancetype)initWithId:(int32_t)id cars:(id<KUMStdlibCollection>)cars numLawnmowers:(BOOL)numLawnmowers percentUnopenedBoxes:(double)percentUnopenedBoxes NS_SWIFT_NAME(init(id:cars:numLawnmowers:percentUnopenedBoxes:)) NS_DESIGNATED_INITIALIZER;

-(int32_t)component1 NS_SWIFT_NAME(component1());
-(id<KUMStdlibCollection>)component2 NS_SWIFT_NAME(component2());
-(BOOL)component3 NS_SWIFT_NAME(component3());
-(double)component4 NS_SWIFT_NAME(component4());
-(KUMGarage*)doCopyId:(int32_t)id cars:(id<KUMStdlibCollection>)cars numLawnmowers:(BOOL)numLawnmowers percentUnopenedBoxes:(double)percentUnopenedBoxes NS_SWIFT_NAME(doCopy(id:cars:numLawnmowers:percentUnopenedBoxes:));
@property (readonly) int32_t id;
@property (readonly) id<KUMStdlibCollection> cars;
@property (readonly) BOOL numLawnmowers;
@property (readonly) double percentUnopenedBoxes;
@end;

__attribute__((objc_subclassing_restricted))
@interface KUMPerson : KotlinBase
-(instancetype)initWithId:(int32_t)id numEyes:(int32_t)numEyes tongueLengthCentimeter:(double)tongueLengthCentimeter tongueWidthDecimeter:(double)tongueWidthDecimeter isFunny:(BOOL)isFunny NS_SWIFT_NAME(init(id:numEyes:tongueLengthCentimeter:tongueWidthDecimeter:isFunny:)) NS_DESIGNATED_INITIALIZER;

-(int32_t)component1 NS_SWIFT_NAME(component1());
-(int32_t)component2 NS_SWIFT_NAME(component2());
-(double)component3 NS_SWIFT_NAME(component3());
-(double)component4 NS_SWIFT_NAME(component4());
-(BOOL)component5 NS_SWIFT_NAME(component5());
-(KUMPerson*)doCopyId:(int32_t)id numEyes:(int32_t)numEyes tongueLengthCentimeter:(double)tongueLengthCentimeter tongueWidthDecimeter:(double)tongueWidthDecimeter isFunny:(BOOL)isFunny NS_SWIFT_NAME(doCopy(id:numEyes:tongueLengthCentimeter:tongueWidthDecimeter:isFunny:));
@property (readonly) int32_t id;
@property (readonly) int32_t numEyes;
@property (readonly) double tongueLengthCentimeter;
@property (readonly) double tongueWidthDecimeter;
@property (readonly) BOOL isFunny;
@end;

@protocol KUMStdlibIterable
@required
-(id<KUMStdlibIterator>)iterator NS_SWIFT_NAME(iterator());
@end;

@protocol KUMStdlibCollection <KUMStdlibIterable>
@required
-(BOOL)containsElement:(id _Nullable)element NS_SWIFT_NAME(contains(element:));
-(BOOL)containsAllElements:(id<KUMStdlibCollection>)elements NS_SWIFT_NAME(containsAll(elements:));
-(BOOL)isEmpty NS_SWIFT_NAME(isEmpty());
@property (readonly) int32_t size;
@end;

@protocol KUMStdlibIterator
@required
-(BOOL)hasNext NS_SWIFT_NAME(hasNext());
-(id _Nullable)next NS_SWIFT_NAME(next());
@end;

NS_ASSUME_NONNULL_END
